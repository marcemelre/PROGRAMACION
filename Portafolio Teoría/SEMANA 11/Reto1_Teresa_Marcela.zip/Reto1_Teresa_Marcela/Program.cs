﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto1_Teresa_Marcela
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] niveles = new int[5];
            int x = 0;
            int suma=0;
            int maspersonas = 0;

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese la cantidad de personas en el nivel " + (i+1));
                niveles [i] = int.Parse(Console.ReadLine());
            }

            for (int i = 0; i < 5; i++)
            {
                if (x < niveles[i] )
                {
                    x = niveles[i];
                   
                    maspersonas = i+1;
                }
            }
            Console.WriteLine("El nivel con mayor numero de personas es: " + maspersonas);

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("El numero de personas en el nivel " + (i + 1) + "es de : "  + niveles[i]);
                suma += niveles [i];
            }


            Console.WriteLine("La cantidad de personas en el edificio es de : " + suma);
            
            Console.ReadKey();
            //RETO 1 SEMANA 11 por Marcela y Teresa
        }
    }
}
