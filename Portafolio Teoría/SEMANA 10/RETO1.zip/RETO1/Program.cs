﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RETO_1_SEMANA10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String mifuncion(int dato1, int dato2, int dato3)
            {
                if ((dato1 > 0) && (dato2 > 0) && (dato3 > 0))
                {
                    double promedio;
                    double suma;
                    double multiplicacion;
                    double elevado;
                    double mediageometrica;
                    suma = (dato1 + dato2 + dato3);
                    multiplicacion = dato1 * dato2 * dato3;
                    elevado = Math.Pow(dato1, dato2);
                    promedio = suma / 3;
                    mediageometrica = Math.Pow(multiplicacion, 1 / 3);
                    Console.WriteLine("La suma es " + suma.ToString());
                    Console.WriteLine("La media es " + promedio.ToString());
                    Console.WriteLine("La multiplicatoria es " + multiplicacion.ToString());
                    Console.WriteLine("La media geometrica es " + mediageometrica.ToString());
                    Console.WriteLine(dato1.ToString() + " ^ " + dato2.ToString() + " = " + elevado.ToString());
                    return "Se hicieron todos los cálculos correctamente";
                }
                else
                    return "Debe ingresar valores mayores a 0";

            }
            
            //la función calcula la suma, multiplicacion, media, media geometrica y la potencia de los numeros enviados como parámetros//
            

            Console.WriteLine(mifuncion(2, 4, 6));
            Console.ReadKey();
        }
    }
}
