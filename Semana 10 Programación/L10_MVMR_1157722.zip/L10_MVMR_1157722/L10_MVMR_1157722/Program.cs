﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10_MVMR_1157722
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string usuario;
            string contraseña;
            int intentos = 0;
            int veces = 0;
            bool condicion = false;
            while (veces < 3)
            {
                Console.WriteLine("Ingrese el usuario:");
                usuario = Console.ReadLine();
                Console.WriteLine("Ingrese la contraseña:");
                contraseña = Console.ReadLine();

                condicion = Login(usuario, contraseña);
                if (condicion == true)
                {
                    veces = 3;
                    Console.WriteLine("¡La sesión fue iniciada exitosamente!");
                }
                else
                {
                    Console.WriteLine("La sesión no se pudo iniciar, intentos: " + (intentos + 1));
                    intentos++;
                    veces++;
                }
                if (intentos == 3)
                {
                    Console.WriteLine("Sus intentos se han agotado");
                }
            }
            Console.ReadKey();
        }
        static bool Login(string usuario, string contraseña)
        {
            if (usuario == "usuario1" && contraseña == "asdasd")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
