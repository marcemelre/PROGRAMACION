﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Authentication;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO_FINAL_MTSB_MVMR
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int habitaciones = 4;
            double amin = 0;
            double amax = 0;
            int nopcion;
            int ence;
            int apa;
            double promediomin = 0;
            double promediomax=0;



            //Este es el menú principal de la configuración del sistema de automatización del hogar
            Console.WriteLine("Bienvenido al sistema de automatización de su hogar");
        Regresar://etiqueta->procedimiento inicial
            Console.WriteLine(" ---------------------------------------------");
            Console.WriteLine("|Seleccione la opción que desea configurar    |");
            Console.WriteLine("|   1. Sistema de ventilación                 |");
            Console.WriteLine("|   2. Sistema de calefacción                 |");
            Console.WriteLine("|   3. Sistema de iluminación                 |");
            Console.WriteLine("|   4. Panel de control                       |");
            Console.WriteLine("|   5. Salida                                 |");
            Console.WriteLine(" ---------------------------------------------");
            Console.Write("Coloque su número de opción: ");
            nopcion = Convert.ToInt32(Console.ReadLine());


            //Esta condición es para definir un rango de las opciones que el usuario puede elegir
            if (nopcion < 1 ||
                nopcion > 5)
            {
                Console.WriteLine("");
                Console.WriteLine("Error, la opción no es válida");
                goto Regresar;//permite volver al procedimiemto inicial
            }
            if (nopcion == 5)
            {
                Console.WriteLine("");
                Console.WriteLine("El programa ha finalizado");

            }

            if (nopcion < 4)
            {
                Console.WriteLine("");
                //Este mensaje de error aparece cuando el usuario escoge las opciones de ventilación, calefacción e iluminación; ya que el usuario no tiene acceso a estas opciones
                Console.WriteLine("Error, usted no tiene acceso a esta opción. Por favor seleccione otra opción");
                goto Regresar;
            }
            else if (nopcion == 4)
            {
                int panel;
                panel = 0;
                while (panel != 4)   // Si el usuario escoge esta opción le aparece otro menú con las opciones que si puede elegir el usuario para configurar
                {
                    Console.Clear();
                    Console.WriteLine("Bienvenido al menú de panel de control");
                    Console.WriteLine(" ---------------------------------------------------");
                    Console.WriteLine("|Seleccione la opción que desee configurar          |");
                    Console.WriteLine("|   1. Programar las horas de ventilación           |");
                    Console.WriteLine("|   2. Programar la temperaturas máximas y mínimas  |");
                    Console.WriteLine("|   3. Obtener el promedio de las temperaturas      |");
                    Console.WriteLine("|   4. Salir del panel                              |");
                    Console.WriteLine(" ---------------------------------------------------");
                    Console.Write("");
                    Console.Write("Coloque su número de opción: ");

                    panel = Convert.ToInt32(Console.ReadLine());
                    switch (panel)//se crean los menús
                    {
                        case 1://Este caso configura las horas de ventilación en las habitaciones de la casa del usuario.
                            {
                                Console.Clear();
                                Console.WriteLine("");
                                Console.WriteLine("Bienvenido al sistema de ventilación para configurar las horas");
                                Console.WriteLine("Ingrese la cantidad de horarios que usted desea configurar");
                                int canth = Convert.ToInt32(Console.ReadLine());
                                string[] horasencendido;
                                horasencendido = new string[canth];
                                string[] horasapagado;
                                horasapagado = new string[canth];
                                int humedad;
                                string encender;
                                string apagar;
                                string puntosencender;
                                string puntosapagar;

                                for (int i = 0; i < canth; i++)//Esta condición representa la forma de ingresar la hora de encender la ventilación solicitada al usuario, la cual es en forma de cadena
                                {

                                    Console.WriteLine("La hora a ingresar debe ser de la siguiente forma: HH:MM");
                                    Console.WriteLine("Ingrese la hora en la que desea encender la ventilación");
                                    horasencendido[i] = Console.ReadLine();
                                    encender = horasencendido[i].Substring(0, 2);
                                    ence = Convert.ToInt32(encender);
                                    puntosencender = horasencendido[i].Substring(2, 1);



                                    while (ence < 0 || ence > 23)//Esta condición representa el rango de horas que el usuario tiene permitido ingresar
                                    {
                                        Console.WriteLine("Error, el horario ingresado no se encuentra en el rango permitido");
                                        Console.WriteLine("Ingrese la hora que desea encender la ventilación");
                                        horasencendido[i] = Console.ReadLine();
                                        encender = horasencendido[i].Substring(0, 2);
                                        ence = Convert.ToInt32(encender);
                                    }
                                    while (puntosencender != ":")//Esta condición representa que si no está ":" escrito en la hora, está se volverá una hora inválida
                                    {
                                        Console.WriteLine("El formato de hora es incorrecto, ingrese la hora de nuevo");
                                        Console.WriteLine("Ingrese la hora que desea encender la ventilación");
                                        horasencendido[i] = Console.ReadLine();
                                        puntosencender = horasencendido[i].Substring(2, 1);
                                    }

                                }

                                for (int i = 0; i < canth; i++)//Esta condición representa la forma de ingresar la hora de apagar la ventilación solicitada al usuario, la cual es en forma de cadena
                                {

                                    Console.WriteLine("Ingrese la hora en la que desea apagar la ventilación");
                                    Console.WriteLine("La hora a ingresar debe ser de la siguiente forma: HH:MM");
                                    horasapagado[i] = Console.ReadLine();
                                    apagar = horasapagado[i].Substring(0, 2);
                                    apa = Convert.ToInt32(apagar);
                                    puntosapagar = horasapagado[i].Substring(2, 1);

                                    while (apa < 0 || apa > 23) //Esta condición representa el rango de horas que el usuario tiene permitido ingresar
                                    {
                                        Console.WriteLine("Error, el horario ingresado no se encuentra en el rango permitido");
                                        Console.WriteLine("Ingrese la hora que desea apagar la ventilación");
                                        horasapagado[i] = Console.ReadLine();
                                        apa = Convert.ToInt32(apagar);
                                    }
                                    while (puntosapagar != ":")//Esta condición representa que si no está ":" escrito en la hora, está se volverá una hora inválida

                                    {
                                        Console.WriteLine("El formato de hora es incorrecto, ingrese la hora de nuevo");
                                        Console.WriteLine("Ingrese la hora que desea apagar la ventilación");
                                        horasapagado[i] = Console.ReadLine();
                                        puntosapagar = horasapagado[i].Substring(2, 1);
                                    }

                                }
                                habitaciones = 0;
                                while (habitaciones != 5)//Esta condición representa que mientras la opción que eliga el usuario sea diferente de 5, le saldrán las siguientes opciones
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine("Configuración de las habitaciones");
                                    Console.WriteLine("1. Habitación 1");
                                    Console.WriteLine("2. Habitación 2");
                                    Console.WriteLine("3. Habitación 3");
                                    Console.WriteLine("4. Habitación 4");
                                    Console.WriteLine("5. Salir ");
                                    Console.WriteLine(" ");
                                    Console.Write("Ingrese el número de habitación que desea configurar: ");
                                    habitaciones = Convert.ToInt32(Console.ReadLine());
                                    while (habitaciones < 1 || habitaciones > 5)//Esta condición representa el rango que el usuario tiene permitido ingresar para poder configurar
                                    {
                                        Console.WriteLine("La opción ingresada no es la correcta. Vuelva a ingresar el número");
                                        Console.WriteLine("Ingrese el número de habitación que desea configurar");
                                        habitaciones = Convert.ToInt32(Console.ReadLine());
                                    }
                                    switch (habitaciones)
                                    {
                                        case 1://Este caso representa la opción de ventilación de la habitación 1 de la casa del usuario, en donde le aparece el nivel de humedad de la habitación y dependiendo de la hora ingresada y compararla con la hora de la computadora, le avisa si la ventilación está encendida o le notifica a que hora se encenderá
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Ventilación de la habitación 1");
                                                string hcomputadora = Convert.ToString(DateTime.Now.ToString("HH:mm"));//Esta función sirve para validar la hora que el usuario ingrese con la hora de la computadora
                                                Random num = new Random();
                                                humedad = num.Next(100);
                                                Console.WriteLine("El nivel de humedad de la habitación 1 es: " + humedad);
                                                if (humedad > 70)
                                                {
                                                    Console.WriteLine("La ventilación de la habitación está encendida");
                                                }
                                                else
                                                {
                                                    for (int i = 0; i < canth; i++)
                                                    {
                                                        if (horasencendido[i] == hcomputadora)
                                                        {
                                                            Console.WriteLine("La ventilación está encendida");
                                                        }
                                                        else
                                                        {
                                                            Console.WriteLine("La ventilación se encenderá a las: " + horasencendido[i] + " horas");
                                                            Console.WriteLine("La ventilación se apagará a las: " + horasapagado[i] + " horas");
                                                        }
                                                    }
                                                }
                                            }
                                            break;
                                        case 2://Este caso representa la opción de ventilación de la habitación 2 de la casa del usuario, en donde le aparece el nivel de humedad de la habitación y dependiendo de la hora ingresada y compararla con la hora de la computadora, le avisa si la ventilación está encendida o le notifica a que hora se encenderá
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Ventilación de la habitación 2");
                                                string hcomputadora = Convert.ToString(DateTime.Now.ToString("HH:mm"));
                                                int humedad1;
                                                Random num = new Random();
                                                humedad1 = num.Next(100);
                                                Console.WriteLine("El nivel de humedad de la habitación 2 es: " + humedad1);
                                                if (humedad1 > 70)
                                                {
                                                    Console.WriteLine("La ventilación de la habitación está encendida");
                                                }
                                                else
                                                {
                                                    for (int i = 0; i < canth; i++)
                                                    {
                                                        if (horasencendido[i] == hcomputadora)
                                                        {
                                                            Console.WriteLine("La ventilación está encendida");
                                                        }
                                                        else
                                                        {
                                                            Console.WriteLine("La ventilación se encenderá a las: " + horasencendido[i] + " horas");
                                                            Console.WriteLine("La ventilación se apagará a las: " + horasapagado[i]+" horas");
                                                        }
                                                    }
                                                }
                                            }
                                            break;
                                        case 3://Este caso representa la opción de ventilación de la habitación 3 de la casa del usuario, en donde le aparece el nivel de humedad de la habitación y dependiendo de la hora ingresada y compararla con la hora de la computadora, le avisa si la ventilación está encendida o le notifica a que hora se encenderá
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Ventilación de la habitación 3");
                                                string hcomputadora = Convert.ToString(DateTime.Now.ToString("HH:mm"));
                                                int humedad2;
                                                Random num = new Random();
                                                humedad2 = num.Next(100);
                                                Console.WriteLine("El nivel de humedad de la habitación 3 es: " + humedad2);
                                                if (humedad2 > 70)
                                                {
                                                    Console.WriteLine("La ventilación de la habitación está encendida");
                                                }
                                                else
                                                {
                                                    for (int i = 0; i < canth; i++)
                                                    {
                                                        if (horasencendido[i] == hcomputadora)
                                                        {
                                                            Console.WriteLine("La ventilación está encendida");
                                                        }
                                                        else
                                                        {
                                                            Console.WriteLine("La ventilación se encenderá a las: " + horasencendido[i] + " horas");
                                                            Console.WriteLine("La ventilación se apagará a las: " + horasapagado[i] + " horas");
                                                        }
                                                    }
                                                }
                                            }
                                            break;
                                        case 4://Este caso representa la opción de ventilación de la habitación 4 de la casa del usuario, en donde le aparece el nivel de humedad de la habitación y dependiendo de la hora ingresada y compararla con la hora de la computadora, le avisa si la ventilación está encendida o le notifica a que hora se encenderá
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Ventilación de la habitación 4");
                                                string hcomputadora = Convert.ToString(DateTime.Now.ToString("HH:mm"));
                                                int humedad3;
                                                Random num = new Random();
                                                humedad3 = num.Next(100);
                                                Console.WriteLine("El nivel de humedad de la habitación 4 es: " + humedad3);
                                                if (humedad3 > 70)
                                                {
                                                    Console.WriteLine("La ventilación de la habitación está encendida");
                                                }
                                                else
                                                {
                                                    for (int i = 0; i < canth; i++)
                                                    {
                                                        if (horasencendido[i] == hcomputadora)
                                                        {
                                                            Console.WriteLine("La ventilación está encendida");
                                                        }
                                                        else
                                                        {
                                                            Console.WriteLine("La ventilación se encenderá a las: " + horasencendido[i] + " horas");
                                                            Console.WriteLine("La ventilación se apagará a las: " + horasapagado[i] + " horas");
                                                        }
                                                    }
                                                }
                                            }
                                            break;
                                    }
                                }
                                break;

                            }

                        case 2://Este caso representa el sistema de calefacción de la casa del usuario en donde el usuario puede configurar las temperaturas tanto máximas como mínimas que quiere.
                            {

                                Console.WriteLine("Bienvenido al sistema de calefacción para configurar las temperaturas máximas y mínimas");
                                Console.WriteLine("La cantidad de habitaciones que tiene en su hogar es de 4");

                                int[] tempmax;
                                tempmax = new int[habitaciones];
                                amax = 0;
                               

                                for (int i = 0; i < habitaciones; i++)
                                {

                                    Console.WriteLine("Ingrese la temperatura máxima que desea configurar para la habitación " + (i + 1));
                                    tempmax[i] = Convert.ToInt32(Console.ReadLine());


                                    while (tempmax[i] < 18 || tempmax[i] > 30)//Esta condición representa el rango de temperaturas máximas que tiene permitido el usuario
                                    {
                                        Console.WriteLine("Error, la temperatura ingresada no se encuentra en el rango permitido");
                                        Console.WriteLine("Ingrese la temperatura mínima que desea configurar");
                                        tempmax[i] = Convert.ToInt32(Console.ReadLine());
                                    }
                                    amax = amax + tempmax[i];

                                    if (tempmax[i] == 22)
                                    {
                                        Console.WriteLine("Temperatura ideal ");
                                    }

                                    if (tempmax[i] < 22)
                                    {
                                        Console.WriteLine("Calefacción encendida por temperatura baja");//Por temperatura baja
                                    }
                                    else
                                    {
                                        Console.WriteLine("Ventilación encendida por temperatura alta");//Por temperatura alta
                                    }

                                    
                                }


                                int[] tempmin;
                                tempmin = new int[habitaciones];
                                amin = 0;

                                for (int i = 0; i < habitaciones; i++)
                                {

                                    Console.WriteLine("Ingrese la temperatura mínima que desea configurar para la habitación " + (i + 1));
                                    tempmin[i] = Convert.ToInt32(Console.ReadLine());

                                    while (tempmin[i] < 18 || tempmin[i] > 30)//Esta condición representa el rango de temperaturas mínimas que tiene permitido el usuario
                                    //Temperatura no mayor de 30 ya que el cuerpo humano no acepta más de 40 grados
                                    {
                                        Console.WriteLine("Error, la temperatura ingresada no se encuentra en el rango permitido");
                                        Console.WriteLine("Ingrese la temperatura mínima que desea configurar");
                                        tempmin[i] = Convert.ToInt32(Console.ReadLine());
                                    }
                                    amin = amin + tempmin[i];

                                    if (tempmin[i] == 22)
                                    {
                                        Console.WriteLine("Temperatura ideal");
                                    }
                                    if (tempmin[i] < 22)
                                    {
                                        Console.WriteLine("Calefacción encendida por temperatura baja");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Ventilación encendida por temperatura alta");
                                    }
                                   
                                }
                                break;
                            }
                            
                        case 3://Este caso representa el promedio de las temperaturas que el usuario ingresa en el caso anterior
                            promediomax = amax / 4;
                            promediomin = amin / 4;
                           
                                    Console.WriteLine("El promedio de las temperaturas máximas es: " + promediomax);
                                    Console.WriteLine("El promedio de las temperaturas mínimas es: " + promediomin);
                            Console.ReadKey();
                                
                            
                            break;
                        case 4://Este caso representa la opción de regresar al menú principal
                            goto Regresar;
                        default://Esta opción está para cuando el usuario elige una de las opciones que no aparecen en el menú principal de la automatización
                            {
                                Console.WriteLine("");
                                Console.WriteLine("Error, la opción no es válida");
                            }
                            break;
                    }
                }
                return;
            }
            Console.ReadKey();
        }
    }
}