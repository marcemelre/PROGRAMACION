namespace L8_MVMR_1157722
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            switch (Seleccion.SelectedIndex)
            {
                case 0: tabControl1.SelectedIndex = 0; break;
                case 1: tabControl1.SelectedIndex = 1; break;
                case 2: tabControl1.SelectedIndex = 2; break;

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int suma = 0, cuenta = 0;
            do
            {
                suma += cuenta;
                cuenta++;
            } while (cuenta <= int.Parse(NSumatoria.Text));
            Sumatoria.Text = suma.ToString();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int contar,suma = 0,numero = int.Parse(NPerfecto.Text);
            for (contar = 1; contar < numero; contar++)
            {
                if (numero % contar == 0)
                   suma += contar;
            }
            if (suma == numero)
                Perfecto.Text = "Si es perfecto";
            else
                Perfecto.Text = "No es perfecto";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            String resultado = "";
            int i, j;
            for (i=1;i<=10;i++)
            {
                if (i == 1)
                {
                    resultado += "\t";
                    for (j = 1; j <= 10; j++)
                        resultado += j + "\t";
                    resultado += "\n";
                }

                resultado += i + "\t";
                
                for (j=1;j<=10;j++)
                {
                    resultado +=  (i * j) + "\t";
                }
                resultado +=  "\n";
            }
            tablam.Text = resultado;
        }
    }
}