﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1_MVMR_1157722
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola Mundo soy Marcela Melendez");
            
            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy Marcela Melendez");
            /*La diferencia es que el WriteLine tira el mensaje linea por linea y el Console.Write tira el mensaje en una sola linea*/
            Console.Write("Hola Mundo ");
            Console.Write("soy Marcela Melendez");

            Console.WriteLine(" Ingrese su nombre: ");
            string Nombre = Console.ReadLine();

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy " + Nombre);
            /*La diferencia es que el WriteLine tira el mensaje linea por linea y el Console.Write tira el mensaje en una sola linea*/

            Console.Write("Hola Mundo ");
            Console.Write("soy " + Nombre);
            Console.ReadKey();



        }
    }
}
