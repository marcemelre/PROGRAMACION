﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace L12_MVMR_1157722
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int suma = 0;
            double promedio = 0;
            Random numeros = new Random();
            int[,] matriz1 = new int[4, 5];
                for (int f = 0; f < 4; f++)
            {
                for (int c=0; c<5; c++)
                {
                    matriz1[f, c] = numeros.Next(50);
                    suma = suma + matriz1[f,c];
                }
            }
            promedio = suma / matriz1.Length;
            Console.WriteLine("La suma de la matriz 1 es de: " + suma);
            Console.WriteLine("El promedio de la matriz 1 es de: " + promedio);
        
            int[,] matriz2 = new int[4, 5];
            for (int f = 0; f < 4; f++)
            {
                for (int c = 0; c < 5; c++)
                {
                    matriz2[f, c] = numeros.Next(50);
                }
            }
            
            int[,] matriz3 = new int[4, 5];
            for (int f = 0; f < 4; f++)
            {
                for (int c = 0; c < 5; c++)
                {
                    matriz3[f, c] = matriz1[f, c] + matriz2[f, c];
                    Console.Write(matriz3[f,c] + " ");
                }
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
