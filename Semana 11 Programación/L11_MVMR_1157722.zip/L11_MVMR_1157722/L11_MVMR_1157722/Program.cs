﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_MVMR_1157722
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] estudiantes1 = new double[5];
            double[] estudiantes2 = new double[5];
            int aprobados1 = 0;
            int aprobados2 = 0;
            double porcentajeaprobados1 = 0;
            double porcentajeaprobados2 = 0;
            int desaprobados1 = 0;
            int desaprobados2 = 0;
            double porcentajedesaprobados1 = 0;
            double porcentajedesaprobados2 = 0;
            double aprobt = 0;
            double desaprobt = 0;
            double suma1 = 0;
            double suma2 = 0;
            double promedio1 = 0;
            double promedio2 = 0;
            double promediototal = 0;
            double promedio90 = 0;
            double promedio902 = 0;
            double promedio75 = 0;
            double promedio752 = 0;
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese la nota del estudiante " + (i + 1) + " de la sección 1");
                estudiantes1[i] = int.Parse(Console.ReadLine());
                suma1 = suma1 + estudiantes1[i];
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese la nota del estudiante " + (i + 1) + " de la sección 2");
                estudiantes2[i] = int.Parse(Console.ReadLine());
                suma2 = suma2 + estudiantes2[i];
            }
            for (int i = 0; i < 5; i++)
            {
                if (estudiantes1[i] >= 65)
                {
                    aprobados1++;

                }
                else
                {
                    desaprobados1++;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (estudiantes2[i] >= 65)
                {
                    aprobados2++;
                }
                else
                {
                    desaprobados2++;
                }
            }
            porcentajeaprobados1 = (aprobados1 * 100) / estudiantes1.Length;
            Console.WriteLine("El porcentaje de aprobados de la sección 1 es " + porcentajeaprobados1);
            porcentajeaprobados2 = Convert.ToDouble((aprobados2 * 100) / estudiantes2.Length);
            Console.WriteLine("El porcentaje de aprobados de la sección 2 es " + porcentajeaprobados2);
            porcentajedesaprobados1 = Convert.ToDouble((desaprobados1 * 100) / estudiantes1.Length);
            Console.WriteLine("El porcentaje de desaprobados de la sección 1 es " + porcentajedesaprobados1);
            porcentajedesaprobados2 = Convert.ToDouble((desaprobados2 * 100) / estudiantes2.Length);
            Console.WriteLine("El porcentaje de desapobados de la sección 2 es " + porcentajedesaprobados2);
            aprobt = (((aprobados1 + aprobados2) * 100) / (estudiantes1.Length + estudiantes2.Length));
            Console.WriteLine("El porcentaje de aprobados en las dos secciones es " + aprobt);
            desaprobt = (((desaprobados1 + desaprobados2) * 100) / (estudiantes1.Length + estudiantes2.Length));
            Console.WriteLine("El porcentaje de desaprobados en las dos secciones es " + desaprobt);

            promedio1 = (suma1 / estudiantes1.Length);
            Console.WriteLine("El promedio de las notas de la sección 1 es " + promedio1);

            promedio2 = (suma2 / estudiantes2.Length);
            Console.WriteLine("El promedio de las notas de la sección 2 es " + promedio2);

            promediototal = ((suma1 + suma2) / (estudiantes1.Length + estudiantes2.Length));
            Console.WriteLine("El promedio total de las notas de las dos secciones es de " + promediototal);

            for (int i = 0; i < 5; i++)
            {
                if (estudiantes1[i] > 90)
                {
                    promedio90++;
                }
                if (estudiantes2[i] > 90)
                {
                    promedio902++;
                }
            }
            Console.WriteLine("La cantidad de estudiantes con promedio mayor a 90 es de: " + (promedio90+promedio902));
            for (int i = 0; i < 5; i++)
            {
                if (estudiantes1[i] < 75)
                {
                    promedio75++;
                }
                if (estudiantes2[i] < 75)
                {
                    promedio752++;
                }
            }
            Console.WriteLine("La cantidad de estudiantes con promedio menor a 75 es de: " + (promedio75 + promedio752));
            Console.ReadKey();
        }
    }
}
