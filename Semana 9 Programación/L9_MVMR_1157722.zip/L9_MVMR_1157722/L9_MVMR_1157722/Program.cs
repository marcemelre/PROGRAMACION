﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_MVMR_1157722
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int modelo = 0;
            double precio = 0.00;
            string marca = "";
            bool disponible = false;
            string sdisponible = "";
            double tipoCambiodeDolar = 7.50;
            double descuentoAplicado = 0.00;

            Console.WriteLine("Ingrese el modelo del carro");
            modelo = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese el precio del carro");
            precio = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la marca del carro");
            marca = Console.ReadLine();

            Console.WriteLine("Ingrese la disponibilidad del carro");
            sdisponible = Console.ReadLine();

            if (sdisponible == "disponible")
            {
                disponible = true;
            }

            Console.WriteLine("Ingrese el descuento del carro");
            descuentoAplicado = double.Parse(Console.ReadLine());

            mostrarinformacion(modelo, precio, marca, sdisponible, tipoCambiodeDolar, descuentoAplicado);

            Console.ReadKey();
        }
        static void mostrarinformacion(int modelo, double precio, string marca, string sdisponible, double tipoCambiodeDolar, double descuentoAplicado)
        {
            double descuento = precio - precio * (descuentoAplicado / 100);
            double cambiodolar = (descuento / tipoCambiodeDolar);

            Console.WriteLine("Marca " + marca + ". Modelo " + modelo + ". Precio " + descuento + ". Precio en dolares " + cambiodolar + ". Mostrar disponibilidad " + sdisponible);
        }
    }
}
