﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_MVMR_1157722
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int modelo = 0;
            double precio = 0.00;
            string marca = "";
            double IVA = 0.12;

            Console.WriteLine("Ingrese el modelo de la motocicleta");
            modelo = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese el precio de la motocicleta");
            precio = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la marca de la motocicleta");
            marca = Console.ReadLine();

            Console.WriteLine("Ingrese el porcentaje del IVA");
            IVA = double.Parse(Console.ReadLine());

            mostrarinformacion(modelo, precio, marca, IVA);

            Console.ReadKey();
        }
        static void mostrarinformacion(int modelo, double precio, string marca, double IVA)
        {
            double calculoiva = precio + (precio * 0.12);
            double soloiva = (precio * 0.12);

            Console.WriteLine("Marca " + marca + ". Modelo " + modelo + ". Precio " + precio + ". Precio con IVA incluido " + calculoiva + ". Solo IVA " + soloiva);
        }
    }
}

